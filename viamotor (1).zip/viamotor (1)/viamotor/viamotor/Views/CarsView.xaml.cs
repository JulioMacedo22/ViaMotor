﻿using System.Windows.Controls;
using ViaMotorApp.ViewModels;

namespace ViaMotorApp.Views
{
    public partial class CarsView : UserControl
    {
        public CarsView()
        {
            InitializeComponent();
            this.DataContext = new CarsViewModel(); // <--- Isto liga o botão!
        }
    }
}