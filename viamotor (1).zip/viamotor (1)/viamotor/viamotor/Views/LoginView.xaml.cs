﻿using System.Windows;

namespace ViaMotorApp.Views
{
    public partial class LoginView : Window
    {
        public LoginView()
        {
            InitializeComponent();
        }

        
        private void BtnSair_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown(); // Fecha a aplicação totalmente
        }
    }
}