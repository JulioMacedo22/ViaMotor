﻿using System.Windows.Controls;
using ViaMotorApp.ViewModels;

namespace ViaMotorApp.Views
{
    public partial class UsersView : UserControl
    {
        public UsersView()
        {
            InitializeComponent();
            this.DataContext = new UsersViewModel(); // <--- Isto liga o botão!
        }
    }
}