﻿using System.Windows.Controls;
using ViaMotorApp.ViewModels;

namespace ViaMotorApp.Views
{
    public partial class SimulationsView : UserControl
    {
        public SimulationsView()
        {
            InitializeComponent();
            this.DataContext = new SimulationsViewModel(); // <--- Isto liga o botão!
        }
    }
}