﻿using System.Windows.Controls;
using ViaMotorApp.ViewModels;

namespace ViaMotorApp.Views
{
    public partial class DashboardView : UserControl
    {
        public DashboardView()
        {
            InitializeComponent();
            // FORÇAR a ligação aqui para garantir que os botões encontram os comandos
            this.DataContext = new DashboardViewModel();
        }
    }
}