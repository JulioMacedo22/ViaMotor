﻿namespace ViaMotorApp.Models
{
    public class SimulationItem
    {
        public string RuleName { get; set; }        // Ex: "BMW -> Seguro"
        public double Confidence { get; set; }      // % Confiança
        public double Support { get; set; }         // % Suporte
        
        // Novos campos para cumprir RF6 (Custos e SWOT)
        public decimal FinancialImpact { get; set; } // Lucro estimado da regra
        public string SwotCategory { get; set; }     // Strength, Weakness, Opportunity, Threat
        public string SwotDescription { get; set; }  // Descrição para o relatório
    }
}