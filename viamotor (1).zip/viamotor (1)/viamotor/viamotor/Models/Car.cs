﻿namespace ViaMotorApp.Models
{
    public class Car
    {
        public int Id { get; set; }
        public string Brand { get; set; }
        public string Model { get; set; }
        public decimal Price { get; set; }
        public int Year { get; set; }

        // Esta é a propriedade que estava a faltar e causava o erro CS0117
        public string Status { get; set; } 
    }
}