﻿using System.Windows;

namespace ViaMotorApp  // <--- TEM DE DIZER ViaMotorApp AQUI
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
    }
}