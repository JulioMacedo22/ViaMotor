﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using ViaMotorApp.Services;
using ViaMotorApp.utils; // Confirma se a tua pasta é 'utils' (minúscula) ou 'Utils'

namespace ViaMotorApp.ViewModels
{
    public class LoginViewModel : ViewModelBase
    {
        // MUDANÇA AQUI: DatabaseServices (Plural)
        private readonly DatabaseServices _dbService;
        private string _username;

        public string Username
        {
            get => _username;
            set { _username = value; OnPropertyChanged(); }
        }

        public ICommand LoginCommand { get; }

        public LoginViewModel()
        {
            // MUDANÇA AQUI: new DatabaseServices()
            _dbService = new DatabaseServices(); 
            LoginCommand = new RelayCommand(ExecuteLogin);
        }

        private void ExecuteLogin(object parameter)
        {
            var passwordBox = parameter as PasswordBox;
            var password = passwordBox?.Password;

            if (string.IsNullOrEmpty(Username) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Preencha todos os campos.");
                return;
            }

            if (_dbService.ValidateUser(Username, password))
            {
                var mainWindow = new MainWindow();
                mainWindow.Show();
                Application.Current.Windows[0].Close();
            }
            else
            {
                MessageBox.Show("Dados incorretos.");
            }
        }
    }
}