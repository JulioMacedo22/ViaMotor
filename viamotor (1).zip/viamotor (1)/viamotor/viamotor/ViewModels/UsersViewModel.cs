﻿using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Input;
using ViaMotorApp.Models;
using ViaMotorApp.Services;
using ViaMotorApp.utils;
using ViaMotorApp.Views;

namespace ViaMotorApp.ViewModels
{
    public class UsersViewModel : ViewModelBase
    {
        private readonly DatabaseServices _dbService;

        public ObservableCollection<User> Users { get; set; }
        
        // Utilizador selecionado
        private User _selectedUser;
        public User SelectedUser 
        { 
            get => _selectedUser; 
            set { _selectedUser = value; OnPropertyChanged(); } 
        }

        public string NewUsername { get; set; }
        public string NewPassword { get; set; }
        public string NewRole { get; set; }

        public ICommand CreateUserCommand { get; }
        public ICommand DeleteUserCommand { get; }
        public ICommand BackCommand { get; }

        public UsersViewModel()
        {
            _dbService = new DatabaseServices();
            Users = new ObservableCollection<User>();
            LoadUsers();

            CreateUserCommand = new RelayCommand(AddUser);
            DeleteUserCommand = new RelayCommand(DeleteUser);
            BackCommand = new RelayCommand(GoBack);
        }

        private void LoadUsers()
        {
            Users.Clear();
            var list = _dbService.GetAllUsers();
            foreach (var user in list) Users.Add(user);
        }

        private void AddUser(object obj)
        {
            if (string.IsNullOrEmpty(NewUsername) || string.IsNullOrEmpty(NewPassword))
            {
                MessageBox.Show("Preencha dados.");
                return;
            }

            if (_dbService.AddUser(NewUsername, NewPassword, NewRole))
            {
                MessageBox.Show("Criado!");
                LoadUsers();
                NewUsername = ""; NewPassword = ""; NewRole = "";
                OnPropertyChanged(nameof(NewUsername));
                OnPropertyChanged(nameof(NewPassword));
                OnPropertyChanged(nameof(NewRole));
            }
        }

        private void DeleteUser(object obj)
        {
            if (SelectedUser == null) { MessageBox.Show("Selecione um utilizador na lista."); return; }

            if (MessageBox.Show("Apagar utilizador?", "Confirmar", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
            {
                _dbService.DeleteUser(SelectedUser.Id);
                LoadUsers();
            }
        }

        private void GoBack(object obj)
{
    // Tenta encontrar a janela principal ativa
    foreach (Window window in Application.Current.Windows)
    {
        if (window.GetType().Name == "MainWindow")
        {
            window.Content = new DashboardView();
            return;
        }
    }

    // Plano B
    if (Application.Current.MainWindow != null)
    {
        Application.Current.MainWindow.Content = new DashboardView();
    }
}
    }
}