﻿using System.Windows;
using System.Windows.Input;
using ViaMotorApp.utils;
using ViaMotorApp.Views;

namespace ViaMotorApp.ViewModels
{
    public class DashboardViewModel : ViewModelBase
    {
        public ICommand GoToCarsCommand { get; }
        public ICommand GoToSimulationsCommand { get; }
        public ICommand GoToUsersCommand { get; }

        public DashboardViewModel()
        {
            GoToCarsCommand = new RelayCommand(OpenCars);
            GoToSimulationsCommand = new RelayCommand(OpenSimulations);
            GoToUsersCommand = new RelayCommand(OpenUsers);
        }

        private void OpenCars(object obj)
        {
            // Teste: Se vires esta mensagem, o botão funciona!
            // MessageBox.Show("A abrir Gestão de Frota..."); 
            NavigateTo(new CarsView());
        }

        private void OpenSimulations(object obj)
        {
            NavigateTo(new SimulationsView());
        }

        private void OpenUsers(object obj)
        {
            NavigateTo(new UsersView());
        }

        private void NavigateTo(object newView)
        {
            // PROCURA A JANELA CERTA ATIVA
            foreach (Window window in Application.Current.Windows)
            {
                if (window.IsActive || window.GetType().Name == "MainWindow")
                {
                    window.Content = newView;
                    return;
                }
            }
            
            // Se não encontrar, tenta a abordagem clássica
            if (Application.Current.MainWindow != null)
            {
                Application.Current.MainWindow.Content = newView;
            }
        }
    }
}