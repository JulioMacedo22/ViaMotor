﻿using System;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Input;
using System.Xml.Linq; // Necessário para ler XML
using Microsoft.Win32; // Necessário para a janela de abrir ficheiros
using ViaMotorApp.Models;
using ViaMotorApp.Services;
using ViaMotorApp.utils;
using ViaMotorApp.Views;

namespace ViaMotorApp.ViewModels
{
    public class CarsViewModel : ViewModelBase
    {
        private readonly DatabaseServices _dbService;

        // Lista de Carros
        public ObservableCollection<Car> Cars { get; set; }

        // Carro Selecionado
        private Car _selectedCar;
        public Car SelectedCar
        {
            get => _selectedCar;
            set 
            { 
                _selectedCar = value; 
                if (_selectedCar != null)
                {
                    Brand = _selectedCar.Brand;
                    Model = _selectedCar.Model;
                    Year = _selectedCar.Year;
                    Price = _selectedCar.Price;
                    OnPropertyChanged(nameof(Brand));
                    OnPropertyChanged(nameof(Model));
                    OnPropertyChanged(nameof(Year));
                    OnPropertyChanged(nameof(Price));
                }
                OnPropertyChanged(); 
            }
        }

        // Campos do Formulário
        public string Brand { get; set; }
        public string Model { get; set; }
        public int Year { get; set; }
        public decimal Price { get; set; }

        // Comandos
        public ICommand AddCarCommand { get; }
        public ICommand UpdateCarCommand { get; }
        public ICommand DeleteCarCommand { get; }
        public ICommand ImportXmlCommand { get; } // <--- Comando de Importação
        public ICommand BackCommand { get; }
        public ICommand ClearCommand { get; }

        public CarsViewModel()
        {
            _dbService = new DatabaseServices();
            Cars = new ObservableCollection<Car>();
            LoadCars();

            AddCarCommand = new RelayCommand(AddCar);
            UpdateCarCommand = new RelayCommand(UpdateCar);
            DeleteCarCommand = new RelayCommand(DeleteCar);
            ImportXmlCommand = new RelayCommand(ImportXml); // Liga à função de importar
            BackCommand = new RelayCommand(GoBack);
            ClearCommand = new RelayCommand(ClearFields);
        }

        private void LoadCars()
        {
            Cars.Clear();
            var list = _dbService.GetAllCars();
            foreach (var car in list) Cars.Add(car);
        }

        // --- FUNÇÃO DE IMPORTAÇÃO EM MASSA (XML) ---
        private void ImportXml(object obj)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Ficheiros XML (*.xml)|*.xml";
            openFileDialog.Title = "Selecione a Base de Dados de Automóveis (XML)";
            
            if (openFileDialog.ShowDialog() == true)
            {
                try
                {
                    // Carrega o XML
                    XDocument doc = XDocument.Load(openFileDialog.FileName);
                    int count = 0;

                    // Procura por todos os elementos <Car> dentro do ficheiro
                    foreach (var element in doc.Descendants("Car"))
                    {
                        // Lê os valores com segurança (evita crash se estiver vazio)
                        string b = element.Element("Brand")?.Value;
                        string m = element.Element("Model")?.Value;
                        string yStr = element.Element("Year")?.Value ?? "2024";
                        string pStr = element.Element("Price")?.Value ?? "0";

                        // Converter números
                        if (int.TryParse(yStr, out int y) && decimal.TryParse(pStr, out decimal p))
                        {
                            if (!string.IsNullOrEmpty(b) && !string.IsNullOrEmpty(m))
                            {
                                // Adiciona à Base de Dados
                                _dbService.AddCar(b, m, y, p);
                                count++;
                            }
                        }
                    }

                    if (count > 0)
                    {
                        MessageBox.Show($"Importação concluída com sucesso!\n{count} viaturas adicionadas à frota.", "Sucesso");
                        LoadCars(); // Atualiza a tabela no ecrã
                    }
                    else
                    {
                        MessageBox.Show("Não foram encontrados carros válidos no ficheiro XML.", "Aviso");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Erro ao ler o ficheiro XML.\nVerifique se o formato está correto.\n\nDetalhe: {ex.Message}", "Erro de Importação");
                }
            }
        }

        private void AddCar(object obj)
        {
            if (string.IsNullOrEmpty(Brand) || string.IsNullOrEmpty(Model)) return;
            if (_dbService.AddCar(Brand, Model, Year, Price)) { LoadCars(); ClearFields(null); }
        }

        private void UpdateCar(object obj)
        {
            if (SelectedCar != null && _dbService.UpdateCar(SelectedCar.Id, Brand, Model, Year, Price)) 
            { LoadCars(); ClearFields(null); }
        }

        private void DeleteCar(object obj)
        {
            if (SelectedCar != null && MessageBox.Show("Tem a certeza que deseja apagar?", "Confirmar", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
            { _dbService.DeleteCar(SelectedCar.Id); LoadCars(); ClearFields(null); }
        }

        private void GoBack(object obj)
        {
            foreach (Window window in Application.Current.Windows)
            {
                if (window.GetType().Name == "MainWindow") { window.Content = new DashboardView(); return; }
            }
            if (Application.Current.MainWindow != null) Application.Current.MainWindow.Content = new DashboardView();
        }

        private void ClearFields(object obj)
        {
            Brand = ""; Model = ""; Year = 0; Price = 0; SelectedCar = null;
            OnPropertyChanged(nameof(Brand)); OnPropertyChanged(nameof(Model)); 
            OnPropertyChanged(nameof(Year)); OnPropertyChanged(nameof(Price));
            OnPropertyChanged(nameof(SelectedCar));
        }
    }
}