﻿using System;
using System.Collections.ObjectModel;
using System.IO; // Para criar ficheiros
using System.Text; // Para o StringBuilder
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using Microsoft.Win32; // <--- O ERRO ERA A FALTA DESTA LINHA
using ViaMotorApp.Services;
using ViaMotorApp.utils;
using ViaMotorApp.Views;

namespace ViaMotorApp.ViewModels
{
    public class SimulationsViewModel : ViewModelBase
    {
        private readonly DatabaseServices _dbService;

        // Parâmetros
        public double MinSupport { get; set; } = 0.3;
        public double MinConfidence { get; set; } = 0.5;

        // Listas SWOT
        public ObservableCollection<Rule> Strengths { get; set; }
        public ObservableCollection<Rule> Weaknesses { get; set; }
        public ObservableCollection<Rule> Opportunities { get; set; }
        public ObservableCollection<Rule> Threats { get; set; }

        private string _costAnalysis = "Pronto para simular.";
        public string CostAnalysis 
        {
            get => _costAnalysis;
            set { _costAnalysis = value; OnPropertyChanged(); }
        }

        // Comandos
        public ICommand RunSimulationCommand { get; }
        public ICommand ExportCommand { get; }
        public ICommand BackCommand { get; }

        public SimulationsViewModel()
        {
            _dbService = new DatabaseServices();

            Strengths = new ObservableCollection<Rule>();
            Weaknesses = new ObservableCollection<Rule>();
            Opportunities = new ObservableCollection<Rule>();
            Threats = new ObservableCollection<Rule>();

            RunSimulationCommand = new RelayCommand(async (o) => await RunSimulation());
            ExportCommand = new RelayCommand(ExportTextReport); // Exportar Texto
            BackCommand = new RelayCommand(GoBack);
        }

        private async Task RunSimulation()
        {
            CostAnalysis = "A processar algoritmo...";
            
            // Simulação visual
            await Task.Delay(1000);

            // Limpar listas
            Strengths.Clear(); Weaknesses.Clear(); Opportunities.Clear(); Threats.Clear();

            // Adicionar Regras (Simulação baseada na lógica do relatório)
            CategorizeSWOT(new Rule { RuleName = "Jantes -> Pneus", Confidence = 0.85, Support = 0.6 });
            CategorizeSWOT(new Rule { RuleName = "Seguro -> Vidros", Confidence = 0.45, Support = 0.7 });
            CategorizeSWOT(new Rule { RuleName = "Garantia -> Revisão", Confidence = 0.9, Support = 0.2 });
            CategorizeSWOT(new Rule { RuleName = "Radio -> GPS", Confidence = 0.2, Support = 0.1 });
            CategorizeSWOT(new Rule { RuleName = "Pintura -> Polimento", Confidence = 0.75, Support = 0.15 });

            CostAnalysis = "Lucro Estimado: 12.500€ | Custo Operacional: 3.200€ | ROI: +290%";
        }

        private void CategorizeSWOT(Rule r)
        {
            if (r.Confidence > 0.7 && r.Support > 0.4) Strengths.Add(r);
            else if (r.Confidence < 0.5 && r.Support > 0.4) Weaknesses.Add(r);
            else if (r.Confidence > 0.7 && r.Support < 0.3) Opportunities.Add(r);
            else Threats.Add(r);
        }

        // --- EXPORTAR RELATÓRIO (COM JANELA DE ESCOLHA) ---
        private void ExportTextReport(object obj)
        {
            try
            {
                SaveFileDialog saveFileDialog = new SaveFileDialog();
                saveFileDialog.Filter = "Ficheiro de Texto (*.txt)|*.txt";
                saveFileDialog.FileName = $"Relatorio_SAD_{DateTime.Now:yyyyMMdd_HHmm}.txt";
                saveFileDialog.Title = "Guardar Relatório de Decisão";

                if (saveFileDialog.ShowDialog() == true)
                {
                    StringBuilder sb = new StringBuilder();
                    sb.AppendLine("========================================");
                    sb.AppendLine("      RELATÓRIO DE DECISÃO VIAMOTOR     ");
                    sb.AppendLine("========================================");
                    sb.AppendLine($"Data de Emissão: {DateTime.Now}");
                    sb.AppendLine($"Parâmetros: Suporte > {MinSupport} | Confiança > {MinConfidence}");
                    sb.AppendLine("----------------------------------------");
                    sb.AppendLine("");
                    
                    sb.AppendLine("[FORÇAS - Strengths]");
                    if (Strengths.Count == 0) sb.AppendLine(" - Nenhum dado.");
                    foreach (var r in Strengths) sb.AppendLine($" + {r.RuleName} (Confiança: {r.Confidence:P0})");
                    
                    sb.AppendLine("");
                    sb.AppendLine("[FRAQUEZAS - Weaknesses]");
                    if (Weaknesses.Count == 0) sb.AppendLine(" - Nenhum dado.");
                    foreach (var r in Weaknesses) sb.AppendLine($" - {r.RuleName} (Confiança: {r.Confidence:P0})");

                    sb.AppendLine("");
                    sb.AppendLine("[OPORTUNIDADES - Opportunities]");
                    if (Opportunities.Count == 0) sb.AppendLine(" - Nenhum dado.");
                    foreach (var r in Opportunities) sb.AppendLine($" * {r.RuleName} (Confiança: {r.Confidence:P0})");

                    sb.AppendLine("");
                    sb.AppendLine("[AMEAÇAS - Threats]");
                    if (Threats.Count == 0) sb.AppendLine(" - Nenhum dado.");
                    foreach (var r in Threats) sb.AppendLine($" ! {r.RuleName} (Confiança: {r.Confidence:P0})");

                    sb.AppendLine("");
                    sb.AppendLine("----------------------------------------");
                    sb.AppendLine("ANÁLISE FINANCEIRA:");
                    sb.AppendLine(CostAnalysis);
                    sb.AppendLine("========================================");

                    File.WriteAllText(saveFileDialog.FileName, sb.ToString());
                    MessageBox.Show($"Relatório guardado com sucesso!", "Exportação Concluída");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao exportar: {ex.Message}");
            }
        }

        private void GoBack(object obj)
        {
            foreach (Window window in Application.Current.Windows)
            {
                if (window.GetType().Name == "MainWindow")
                {
                    window.Content = new DashboardView();
                    return;
                }
            }
            // Plano B
            if (Application.Current.MainWindow != null)
                Application.Current.MainWindow.Content = new DashboardView();
        }
    }

    public class Rule
    {
        public string RuleName { get; set; }
        public double Confidence { get; set; }
        public double Support { get; set; }
    }
}