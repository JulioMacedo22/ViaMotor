﻿using System;
using System.Collections.Generic; // Para o Dictionary
using System.Collections.ObjectModel;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using Microsoft.Win32; // Para o SaveFileDialog
using ViaMotorApp.Services;
using ViaMotorApp.utils;
using ViaMotorApp.Views;

namespace ViaMotorApp.ViewModels
{
    public class SimulationsViewModel : ViewModelBase
    {
        private readonly DatabaseServices _dbService;

        // --- Parâmetros da Simulação ---
        public double MinSupport { get; set; } = 0.15; // 15% (Ideal para detetar nichos)
        public double MinConfidence { get; set; } = 0.4; // 40%

        // --- Listas Matriz SWOT ---
        public ObservableCollection<Rule> Strengths { get; set; }
        public ObservableCollection<Rule> Weaknesses { get; set; }
        public ObservableCollection<Rule> Opportunities { get; set; }
        public ObservableCollection<Rule> Threats { get; set; }

        private string _costAnalysis = "Pronto para gerar inteligência de negócio.";
        public string CostAnalysis 
        {
            get => _costAnalysis;
            set { _costAnalysis = value; OnPropertyChanged(); }
        }

        // --- Tabela de Preços de Extras (Business Intelligence) ---
        // Permite calcular o ROI real baseando-se no valor de mercado de cada item
        private readonly Dictionary<string, double> _precosExtras = new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase)
        {
            { "Jantes", 800.00 },
            { "Pneus", 400.00 },
            { "GPS", 350.00 },
            { "Radio", 150.00 },
            { "Vidros", 250.00 },
            { "Seguro", 600.00 },
            { "Estofos", 500.00 },
            { "Sensores", 200.00 },
            { "Pintura", 1200.00 },
            { "Teto Panoramico", 900.00 }
        };

        // Comandos
        public ICommand RunSimulationCommand { get; }
        public ICommand ExportCommand { get; }
        public ICommand BackCommand { get; }

        public SimulationsViewModel()
        {
            _dbService = new DatabaseServices();

            Strengths = new ObservableCollection<Rule>();
            Weaknesses = new ObservableCollection<Rule>();
            Opportunities = new ObservableCollection<Rule>();
            Threats = new ObservableCollection<Rule>();

            RunSimulationCommand = new RelayCommand(async (o) => await RunSimulation());
            ExportCommand = new RelayCommand(ExportTextReport);
            BackCommand = new RelayCommand(GoBack);
        }

        // --- CÉREBRO DA SIMULAÇÃO ---
        private async Task RunSimulation()
        {
            CostAnalysis = "A executar prospeção de dados (Data Mining)...";
            OnPropertyChanged(nameof(CostAnalysis));

            await Task.Run(() =>
            {
                // 1. Obter Dados Reais da BD
                var transactions = _dbService.GetTransactions();
                int totalVendas = transactions.Count;

                if (totalVendas == 0)
                {
                    Application.Current.Dispatcher.Invoke(() => 
                    {
                        CostAnalysis = "Dados insuficientes para gerar inteligência.";
                        ClearLists();
                    });
                    return;
                }

                // 2. Executar Algoritmo Apriori
                AprioriService apriori = new AprioriService();
                var rules = apriori.ExecuteApriori(transactions, MinSupport, MinConfidence);

                // 3. CÁLCULO FINANCEIRO AVANÇADO
                
                // Custos Operacionais
                double custoFixoServidor = 500.00;
                double custoLicencas = 300.00;
                double custoCampanhaPorRegra = 100.00; // Custo de ativar marketing para cada regra encontrada
                
                double custoTotal = custoFixoServidor + custoLicencas + (rules.Count * custoCampanhaPorRegra);

                // Cálculo de Receita Projetada
                double receitaEstimada = 0;

                foreach(var r in rules)
                {
                    // Extrai o produto alvo da regra (Ex: "Jantes -> Pneus" => "Pneus")
                    // Se a string da regra não tiver "->", usa o nome completo
                    string produtoAlvo = r.RuleName;
                    if (r.RuleName.Contains("->"))
                        produtoAlvo = r.RuleName.Split(new[] { "->" }, StringSplitOptions.None)[1].Trim();
                    
                    // Busca o preço real na tabela (ou usa 100€ se não encontrar)
                    double precoProduto = _precosExtras.ContainsKey(produtoAlvo) ? _precosExtras[produtoAlvo] : 100.00;

                    // Volume de vendas potencial (Suporte * Total)
                    double ocorrenciasReais = r.Support * totalVendas;

                    // Taxa de Conversão estimada (20% da confiança da regra)
                    double taxaConversao = r.Confidence * 0.20; 

                    // Receita = Potencial de Venda * Preço * Taxa Conversão
                    receitaEstimada += (ocorrenciasReais / r.Confidence) * precoProduto * taxaConversao;
                }

                double roi = receitaEstimada - custoTotal;

                // --- NOVA LÓGICA: SUGESTÃO ESTRATÉGICA (GRANDE PORTO + ÁREA) ---
                string sugestaoEstrategica = "";
                
                if (roi > 20000)
                {
                    // Alta Rentabilidade: Zonas Nobres e Espaços Grandes
                    sugestaoEstrategica = "SUGESTÃO: Stand Premium (Boavista / Foz - >500m²).";
                }
                else if (roi > 5000)
                {
                    // Rentabilidade Média: Zonas Urbanas e Espaços Médios
                    sugestaoEstrategica = "SUGESTÃO: Stand Médio (Matosinhos / Maia - 200m²).";
                }
                else
                {
                    // Baixa Rentabilidade: Zonas Periféricas e Espaços Pequenos
                    sugestaoEstrategica = "SUGESTÃO: Stand Low-Cost (Valongo / Gondomar - <100m²).";
                }

                // 4. Atualizar o Ecrã
                Application.Current.Dispatcher.Invoke(() =>
                {
                    ClearLists();
                    foreach (var rule in rules) CategorizeSWOT(rule);

                    // --- RODAPÉ DETALHADO (Custos + Receita + ROI + Sugestão com Área) ---
                    CostAnalysis = $"Custos (Fixos+Mkt): {custoTotal:C} | Receita Est.: {receitaEstimada:C} | ROI: {roi:C} || {sugestaoEstrategica}";
                    OnPropertyChanged(nameof(CostAnalysis));
                });
            });
        }

        private void ClearLists()
        {
            Strengths.Clear(); Weaknesses.Clear(); Opportunities.Clear(); Threats.Clear();
        }

        // Lógica SWOT Otimizada
        private void CategorizeSWOT(Rule r)
        {
            // FORÇA: Confiança > 60% e Suporte > 30% (Vaca Leiteira)
            if (r.Confidence >= 0.6 && r.Support >= 0.3) 
                Strengths.Add(r);
            
            // OPORTUNIDADE: Confiança > 60% mas Suporte < 30% (Nicho / Estrela)
            else if (r.Confidence >= 0.6 && r.Support < 0.3) 
                Opportunities.Add(r);
            
            // FRAQUEZA: Confiança < 60% mas Suporte > 30% (Muita venda, pouca relação)
            else if (r.Confidence < 0.6 && r.Support >= 0.3) 
                Weaknesses.Add(r);
            
            // AMEAÇA: O restante (Pouca venda, pouca relação)
            else 
                Threats.Add(r);
        }

        private void ExportTextReport(object obj)
        {
            try
            {
                SaveFileDialog dlg = new SaveFileDialog();
                dlg.Filter = "Relatório TXT (*.txt)|*.txt";
                dlg.FileName = $"Relatorio_Estrategico_{DateTime.Now:yyyyMMdd}.txt";

                if (dlg.ShowDialog() == true)
                {
                    StringBuilder sb = new StringBuilder();
                    sb.AppendLine("==================================================");
                    sb.AppendLine("         RELATÓRIO DE INTELIGÊNCIA VIAMOTOR       ");
                    sb.AppendLine("==================================================");
                    sb.AppendLine($"Data de Emissão: {DateTime.Now:F}");
                    sb.AppendLine($"Total Vendas Analisadas: {_dbService.GetTransactions().Count}");
                    sb.AppendLine("--------------------------------------------------");
                    
                    sb.AppendLine("");
                    sb.AppendLine("[1. FORÇAS - Alta Rotação]");
                    foreach (var r in Strengths) sb.AppendLine($"  + {r.RuleName} (Conf: {r.Confidence:P0})");

                    sb.AppendLine("");
                    sb.AppendLine("[2. OPORTUNIDADES - Alto Potencial]");
                    foreach (var r in Opportunities) sb.AppendLine($"  * {r.RuleName} (Conf: {r.Confidence:P0})");

                    sb.AppendLine("");
                    sb.AppendLine("[3. FRAQUEZAS - A Melhorar]");
                    foreach (var r in Weaknesses) sb.AppendLine($"  - {r.RuleName} (Conf: {r.Confidence:P0})");

                    sb.AppendLine("");
                    sb.AppendLine("[4. AMEAÇAS - Baixo Desempenho]");
                    foreach (var r in Threats) sb.AppendLine($"  ! {r.RuleName} (Conf: {r.Confidence:P0})");

                    sb.AppendLine("");
                    sb.AppendLine("--------------------------------------------------");
                    sb.AppendLine("CONCLUSÃO DO SISTEMA DE APOIO À DECISÃO:");
                    // O CostAnalysis já contém a string completa com Custos, ROI e Sugestão de Zona/Área
                    sb.AppendLine(CostAnalysis);
                    sb.AppendLine("==================================================");

                    File.WriteAllText(dlg.FileName, sb.ToString());
                    MessageBox.Show("Relatório estratégico exportado com sucesso.", "Concluído");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao exportar: " + ex.Message);
            }
        }

        private void GoBack(object obj)
        {
            foreach (Window window in Application.Current.Windows)
            {
                if (window.GetType().Name == "MainWindow") { window.Content = new DashboardView(); return; }
            }
            if (Application.Current.MainWindow != null) Application.Current.MainWindow.Content = new DashboardView();
        }
    }

    public class Rule
    {
        public string RuleName { get; set; }
        public double Confidence { get; set; }
        public double Support { get; set; }
    }
}