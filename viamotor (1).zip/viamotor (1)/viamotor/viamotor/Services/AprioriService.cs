﻿using System;
using System.Collections.Generic;
using System.Linq;
using ViaMotorApp.ViewModels; // Necessário para usar a classe 'Rule'

namespace ViaMotorApp.Services
{
    public class AprioriService
    {
        // O Algoritmo principal
        public List<Rule> ExecuteApriori(List<List<string>> transactions, double minSupport, double minConfidence)
        {
            var rules = new List<Rule>();
            int totalTransactions = transactions.Count;

            // Se não houver vendas, não há regras
            if (totalTransactions == 0) return rules;

            // PASSO 1: Identificar Itens Frequentes (L1)
            // Conta quantas vezes cada item individual aparece
            var itemCounts = new Dictionary<string, int>();
            foreach (var transaction in transactions)
            {
                // Distinct() garante que se alguém comprou "Pneus, Pneus", conta só 1 vez
                foreach (var item in transaction.Distinct())
                {
                    if (!itemCounts.ContainsKey(item)) itemCounts[item] = 0;
                    itemCounts[item]++;
                }
            }

            // Filtra os itens que não atingem o Suporte Mínimo
            // Suporte = (Nº de Vendas com o Item) / (Total de Vendas)
            var frequentItems = itemCounts
                .Where(x => (double)x.Value / totalTransactions >= minSupport)
                .ToDictionary(x => x.Key, x => x.Value);

            // PASSO 2: Gerar Pares e Regras de Associação (L2)
            // Vamos cruzar os itens frequentes para ver quais pares aparecem juntos
            var itemList = frequentItems.Keys.ToList();
            
            for (int i = 0; i < itemList.Count; i++)
            {
                for (int j = i + 1; j < itemList.Count; j++)
                {
                    string itemA = itemList[i];
                    string itemB = itemList[j];
                    
                    // Conta quantas vezes A e B aparecem juntos na mesma transação
                    int countTogether = 0;
                    foreach (var t in transactions)
                    {
                        if (t.Contains(itemA) && t.Contains(itemB)) countTogether++;
                    }

                    // Calcula o Suporte do Par
                    double pairSupport = (double)countTogether / totalTransactions;
                    
                    // Se o par for frequente, tentamos criar regras
                    if (pairSupport >= minSupport)
                    {
                        // REGRA 1: Se compra A -> Compra B?
                        // Confiança = Suporte(A e B) / Suporte(A)
                        double confidenceAtoB = (double)countTogether / frequentItems[itemA];
                        
                        if (confidenceAtoB >= minConfidence)
                        {
                            rules.Add(new Rule 
                            { 
                                RuleName = $"{itemA} -> {itemB}", 
                                Confidence = confidenceAtoB, 
                                Support = pairSupport 
                            });
                        }

                        // REGRA 2: Se compra B -> Compra A? (Regra Inversa)
                        double confidenceBtoA = (double)countTogether / frequentItems[itemB];
                        
                        if (confidenceBtoA >= minConfidence)
                        {
                            rules.Add(new Rule 
                            { 
                                RuleName = $"{itemB} -> {itemA}", 
                                Confidence = confidenceBtoA, 
                                Support = pairSupport 
                            });
                        }
                    }
                }
            }

            // Ordena as regras: as mais fortes (maior confiança) aparecem primeiro
            return rules.OrderByDescending(r => r.Confidence).ToList();
        }
    }
}