﻿using System;
using System.Collections.Generic;
using System.Linq;
using ViaMotorApp.Models;

namespace ViaMotorApp.Services
{
    public class AprioriService
    {
        // Implementação otimizada conforme Relatório Final (Cap. Problemas e Decisões)
        // Usa HashSet para garantir complexidade O(1) na verificação de itens
        public List<SimulationItem> ExecuteAnalysis(List<List<string>> transactions, double minSupport, double minConfidence)
        {
            var rules = new List<SimulationItem>();
            int n = transactions.Count;
            if (n == 0) return rules;

            // 1. Contagem de Suporte (L1)
            var itemCounts = new Dictionary<string, int>();

            foreach (var transaction in transactions)
            {
                // OTIMIZAÇÃO: HashSet remove duplicados e acelera pesquisa
                var uniqueItems = new HashSet<string>(transaction);
                foreach (var item in uniqueItems)
                {
                    if (!itemCounts.ContainsKey(item)) itemCounts[item] = 0;
                    itemCounts[item]++;
                }
            }

            // 2. Filtragem (Pruning)
            var frequentItems = itemCounts
                .Where(x => (double)x.Value / n >= minSupport)
                .Select(x => x.Key)
                .ToList();

            // 3. Geração de Regras (Pares A -> B)
            for (int i = 0; i < frequentItems.Count; i++)
            {
                for (int j = 0; j < frequentItems.Count; j++)
                {
                    if (i == j) continue;

                    string itemA = frequentItems[i];
                    string itemB = frequentItems[j];

                    int countAB = 0;
                    foreach (var t in transactions)
                    {
                        // Verifica co-ocorrência
                        if (t.Contains(itemA) && t.Contains(itemB)) countAB++;
                    }

                    double supportAB = (double)countAB / n;

                    if (supportAB >= minSupport)
                    {
                        double supportA = (double)itemCounts[itemA] / n;
                        double confidence = supportAB / supportA;

                        if (confidence >= minConfidence)
                        {
                            rules.Add(new SimulationItem
                            {
                                RuleName = $"{itemA} -> {itemB}",
                                Confidence = confidence,
                                Support = supportAB
                            });
                        }
                    }
                }
            }

            return rules.OrderByDescending(r => r.Confidence).ToList();
        }
    }
}