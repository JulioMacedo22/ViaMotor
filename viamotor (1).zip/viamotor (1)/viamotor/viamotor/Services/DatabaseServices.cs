﻿using System;
using System.Collections.Generic;
using Microsoft.Data.SqlClient;
using System.Security.Cryptography;
using System.Text;
using ViaMotorApp.Models;

namespace ViaMotorApp.Services
{
    public class DatabaseServices
    {
        // LIGAÇÃO AO TEU SERVIDOR
        private readonly string _connectionString = @"Server=MACEDO\SQLSERVER;Database=ViaMotorDB;Trusted_Connection=True;TrustServerCertificate=True;";

        // --- UTILIZADORES ---

        public bool ValidateUser(string username, string password)
        {
            string passwordHash = HashPassword(password);
            using (var conn = new SqlConnection(_connectionString))
            {
                try
                {
                    conn.Open();
                    string query = "SELECT COUNT(1) FROM Users WHERE Username = @u AND PasswordHash = @p";
                    using (var cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@u", username);
                        cmd.Parameters.AddWithValue("@p", passwordHash);
                        return (int)cmd.ExecuteScalar() > 0;
                    }
                }
                catch { return false; }
            }
        }

        public List<User> GetAllUsers()
        {
            var list = new List<User>();
            using (var conn = new SqlConnection(_connectionString))
            {
                try
                {
                    conn.Open();
                    string query = "SELECT * FROM Users";
                    using (var cmd = new SqlCommand(query, conn))
                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            list.Add(new User
                            {
                                Id = (int)reader["Id"],
                                Username = reader["Username"].ToString(),
                                Role = reader["Role"].ToString()
                                // Não trazemos a password por segurança
                            });
                        }
                    }
                }
                catch { }
            }
            return list;
        }

        public bool AddUser(string username, string password, string role)
        {
            string passwordHash = HashPassword(password);
            using (var conn = new SqlConnection(_connectionString))
            {
                try
                {
                    conn.Open();
                    string query = "INSERT INTO Users (Username, PasswordHash, Role) VALUES (@u, @p, @r)";
                    using (var cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@u", username);
                        cmd.Parameters.AddWithValue("@p", passwordHash);
                        cmd.Parameters.AddWithValue("@r", role ?? "Vendedor");
                        cmd.ExecuteNonQuery();
                        return true;
                    }
                }
                catch { return false; }
            }
        }

        public bool DeleteUser(int id)
        {
            using (var conn = new SqlConnection(_connectionString))
            {
                try
                {
                    conn.Open();
                    string query = "DELETE FROM Users WHERE Id = @id";
                    using (var cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@id", id);
                        cmd.ExecuteNonQuery();
                        return true;
                    }
                }
                catch { return false; }
            }
        }

        // --- CARROS ---

        public List<Car> GetAllCars()
        {
            var list = new List<Car>();
            using (var conn = new SqlConnection(_connectionString))
            {
                try
                {
                    conn.Open();
                    string query = "SELECT * FROM Cars";
                    using (var cmd = new SqlCommand(query, conn))
                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            list.Add(new Car
                            {
                                Id = (int)reader["Id"], // Importante para editar/apagar
                                Brand = reader["Brand"].ToString(),
                                Model = reader["Model"].ToString(),
                                Year = Convert.ToInt32(reader["Year"]),
                                Price = Convert.ToDecimal(reader["Price"]),
                                Status = reader["Status"].ToString()
                            });
                        }
                    }
                }
                catch { }
            }
            return list;
        }

        public bool AddCar(string brand, string model, int year, decimal price)
        {
            using (var conn = new SqlConnection(_connectionString))
            {
                try
                {
                    conn.Open();
                    string query = "INSERT INTO Cars (Brand, Model, Year, Price, Status) VALUES (@b, @m, @y, @p, 'Disponivel')";
                    using (var cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@b", brand);
                        cmd.Parameters.AddWithValue("@m", model);
                        cmd.Parameters.AddWithValue("@y", year);
                        cmd.Parameters.AddWithValue("@p", price);
                        cmd.ExecuteNonQuery();
                        return true;
                    }
                }
                catch { return false; }
            }
        }

        public bool UpdateCar(int id, string brand, string model, int year, decimal price)
        {
            using (var conn = new SqlConnection(_connectionString))
            {
                try
                {
                    conn.Open();
                    string query = "UPDATE Cars SET Brand=@b, Model=@m, Year=@y, Price=@p WHERE Id=@id";
                    using (var cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@id", id);
                        cmd.Parameters.AddWithValue("@b", brand);
                        cmd.Parameters.AddWithValue("@m", model);
                        cmd.Parameters.AddWithValue("@y", year);
                        cmd.Parameters.AddWithValue("@p", price);
                        cmd.ExecuteNonQuery();
                        return true;
                    }
                }
                catch { return false; }
            }
        }

        public bool DeleteCar(int id)
        {
            using (var conn = new SqlConnection(_connectionString))
            {
                try
                {
                    conn.Open();
                    string query = "DELETE FROM Cars WHERE Id = @id";
                    using (var cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@id", id);
                        cmd.ExecuteNonQuery();
                        return true;
                    }
                }
                catch { return false; }
            }
        }

        // --- AUXILIARES ---
        private string HashPassword(string password)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
                StringBuilder builder = new StringBuilder();
                for (int i = 0; i < bytes.Length; i++) builder.Append(bytes[i].ToString("x2"));
                return builder.ToString();
            }
        }
        
        // Método vazio para compatibilidade com Simulações antigas
        public List<List<string>> GetTransactions() { return new List<List<string>>(); }
    }
}