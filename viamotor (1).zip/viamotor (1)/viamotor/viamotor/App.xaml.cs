﻿using System.Windows;

namespace ViaMotorApp // <--- ESTAVA 'viamotor'? MUDA PARA 'ViaMotorApp'
{
    public partial class App : Application
    {
    }
}