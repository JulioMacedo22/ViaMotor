USE master;
GO

-- 1. Se a base de dados j� existir, apaga-a para come�ar do zero
IF EXISTS (SELECT * FROM sys.databases WHERE name = 'ViaMotorDB')
BEGIN
    ALTER DATABASE ViaMotorDB SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
    DROP DATABASE ViaMotorDB;
END
GO

-- 2. Cria a Base de Dados Nova
CREATE DATABASE ViaMotorDB;
GO

USE ViaMotorDB;
GO

-- 3. Cria a Tabela de Utilizadores (RF1 - Autentica��o)
CREATE TABLE Users (
    Id INT PRIMARY KEY IDENTITY(1,1),
    Username NVARCHAR(50) NOT NULL UNIQUE,
    PasswordHash NVARCHAR(256) NOT NULL, -- Guarda a hash, n�o o texto
    Role NVARCHAR(20) DEFAULT 'Admin'
);
GO

-- 4. Cria a Tabela de Carros (RF2 - Gest�o de Stock)
CREATE TABLE Cars (
    Id INT PRIMARY KEY IDENTITY(1,1),
    Brand NVARCHAR(50) NOT NULL,
    Model NVARCHAR(50) NOT NULL,
    Price DECIMAL(18,2) NOT NULL,
    Year INT NOT NULL,
    Status NVARCHAR(20) DEFAULT 'Disponivel' -- 'Disponivel', 'Vendido'
);
GO

-- 5. Cria a Tabela de Vendas (RF4 - Algoritmo Apriori)
-- Esta tabela guarda os "Extras" vendidos juntos para o algoritmo analisar
CREATE TABLE Sales (
    Id INT PRIMARY KEY IDENTITY(1,1),
    CarId INT,
    SaleDate DATETIME DEFAULT GETDATE(),
    Extras NVARCHAR(MAX) -- Ex: "Pneus,Jantes,Seguro"
);
GO

-- =============================================
-- INSER��O DE DADOS (Obrigat�rio para funcionar)
-- =============================================

-- Inserir o ADMIN (Password: admin123)
-- Esta Hash � o resultado de SHA256("admin123")
INSERT INTO Users (Username, PasswordHash)
VALUES ('admin', '240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa822809f74c720a9');

-- Inserir Carros de Exemplo (Para a grelha n�o aparecer vazia)
INSERT INTO Cars (Brand, Model, Price, Year, Status) VALUES 
('Mercedes', 'Classe A', 25000, 2020, 'Disponivel'),
('BMW', 'Serie 3', 32000, 2021, 'Disponivel'),
('Audi', 'A4 Avant', 28500, 2019, 'Vendido'),
('Tesla', 'Model 3', 45000, 2023, 'Disponivel'),
('Renault', 'Clio', 12000, 2018, 'Disponivel');

-- Inserir Vendas (Para a Simula��o SWOT ter dados para analisar)
INSERT INTO Sales (Extras) VALUES 
('Jantes,Pneus,Seguro'),
('Jantes,Pneus'),
('Seguro,Garantia'),
('Jantes,Pneus,Garantia'),
('Radio,GPS'),
('Jantes,Pneus');
-- Com estes dados, a regra "Jantes -> Pneus" ser� uma FOR�A na SWOT.
GO